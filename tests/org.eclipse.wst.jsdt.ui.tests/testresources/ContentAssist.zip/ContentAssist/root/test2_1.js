new Aw

new ba

new bar.C

new bar.fo

new bar.foo.C

new C

new bar.

z //needed because the bar. causes compile issues