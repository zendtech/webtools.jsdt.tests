var obj = new Crazy();
obj.