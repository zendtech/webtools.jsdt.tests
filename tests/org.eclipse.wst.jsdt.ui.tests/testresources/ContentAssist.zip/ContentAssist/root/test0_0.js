function funcOne() {

}

function funcTwo() {
	return "";
}

function funcThree(paramOne) {
	
}

function funcFour(paramOne, paramTwo) {
	return paramOne * paramTwo;
}

/**
 * 
 * @param {Number} paramOne
 * @param {String} paramTwo
 * @returns {String}
 */
function funcFive(paramOne, paramTwo) {
	return "hello";
}

/**
 * 
 * @param paramOne
 * @param {String} paramTwo
 * @returns {Number}
 */
function funcSix(paramOne, paramTwo) {
	return 7;
}

/**
 * 
 * @param {String} paramOne
 * @param paramTwo
 * @returns {Number}
 */
function funcSeven(paramOne, paramTwo) {
	return 7;
}

var funcEight = function(paramOne) {
	return "";
};


funcNine = function(paramOne) {
	return 42;
};



f

func

funcT
