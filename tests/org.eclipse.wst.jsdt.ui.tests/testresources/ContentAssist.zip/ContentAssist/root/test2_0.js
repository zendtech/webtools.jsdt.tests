function Awesome(param1, param2) {
	this.param1 = param1;
	this.param2 = param2;
};

var bar = {
	foo: {},
	foobla : {},
	neto : {}
};
bar.Class1 = function(a, b) {};
bar.Class1.prototype = new Object();
bar.Class2 = function(c, d, e) {};
bar.Class2.prototype = new Object();
bar.foo.Class3 = function(param1, param2, param3, param4) {};
bar.foo.Class3.prototype = new Object();

new 

new Aw

new ba

new bar.C

new bar.fo

new bar.foo.C

new C

new bar.

z //needed because the bar. causes compile issues