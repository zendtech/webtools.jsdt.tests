function Crazy() {
	this.foo = "foo";
}

/**
 * 
 * @param {Number} param1
 */
Crazy.prototype.myFunc1 = function(param1) {
	return param1;
};